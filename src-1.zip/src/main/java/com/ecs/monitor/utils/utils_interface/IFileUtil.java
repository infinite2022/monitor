package com.ecs.monitor.utils.utils_interface;

public interface IFileUtil {

    String generalFileInfo(String absoluteFilePath,String fileName);
}
