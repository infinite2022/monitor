package com.ecs.monitor.controller;

public class SmSController {
}
