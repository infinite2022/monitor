package com.ecs.monitor.dao;

public class ProjProcessMapper {
}
