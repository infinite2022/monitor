package com.ecs.monitor.dao;

public class ProjParams {
}
