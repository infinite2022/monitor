package com.ecs.monitor.dao;

public class ProjRole {
}
