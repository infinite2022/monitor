package com.ecs.monitor.service;

import com.ecs.monitor.bean.ProjProcess;
import com.ecs.monitor.common.FileType;
import com.ecs.monitor.utils.BashExecutor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class ProcessService {

    @Autowired
    BashExecutor bashExecutor;

    public boolean srartProcess(FileType fileType,String fileName){
        switch(fileType.ordinal()){
            case FileType.mysql_type:


                break;
            case FileType.tomcat_type:


                break;
            default:  //jar包相关类型


                break;
        }

        return false;
    }
    public boolean restartProcess(){
        return false;
    }
    //清理指定进程
    public boolean killProcess(){
        return false;
    }
    //取得所有列表
    public List<ProjProcess> getAllProcess(){
        return null;
    }
    //取得失败列表
    public List<ProjProcess> getFailureProcess(){
        return null;
    }
    //添加
    public void addProjProcess(){
    }
    //删除
    public void delProjProcess(){
    }
    //更新
    public void updateProjProcess(){

    }

}
