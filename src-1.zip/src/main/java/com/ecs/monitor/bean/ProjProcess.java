package com.ecs.monitor.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class ProjProcess {

    private int id;
    private int pid;//进程号
    private String pname;//程序名
    private String fpath;//文件路径
    private int status;//状态 0启动，1停止
    private int daemon;//0非守护进程，1守护进程
    private int version;
    private int deleted;//1正常，0删除
    private Date pmtCreate;
    private Date pmtUpdate;

}
