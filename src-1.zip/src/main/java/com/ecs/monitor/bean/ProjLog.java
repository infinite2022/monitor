package com.ecs.monitor.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class ProjLog {

    private long id;
    private String pname;
    private int pid;
    private int status;
    private int type;
    private Date pmtUpdate;
    private String log;

}
