package com.ecs.monitor.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class ProjRole {
    private int id;
    private int mobile;
    private String password;
    private int level;
    private int version;
    private int deleted;//1正常，0删除
    private Date pmtCreate;
    private Date pmtUpdate;

}
