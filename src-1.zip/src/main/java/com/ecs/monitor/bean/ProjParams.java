package com.ecs.monitor.bean;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class ProjParams {
    private int id;
    private int scnaDelay;
    private int keepLogTime;
    private int isActive;
    private int version;
    private int deleted;
    private Date pmtCreate;
    private Date pmtUpdate;
}
