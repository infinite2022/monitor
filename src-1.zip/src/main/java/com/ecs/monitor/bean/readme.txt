database: sys_monitor

tables:

CREATE TABLE `proj1_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pname` char(30) NOT NULL COMMENT '进程名称',
  `pid` int(11) DEFAULT NULL COMMENT '进程号',
  `status` int(2) DEFAULT '1' COMMENT '状态 0启动，1停止',
  `type` int(2) DEFAULT '0' COMMENT '0系统检测，1人工处理',
  `pmt_update` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '记录时间',
  `log` varchar(255) DEFAULT NULL COMMENT '日志信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='程序运行日志';

CREATE TABLE `proj1_params` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `scan_delay` int(10) unsigned NOT NULL COMMENT '扫描等待时间单位S',
  `keey_log_time` int(11) NOT NULL COMMENT '日志保留时间',
  `is_active` int(11) DEFAULT NULL COMMENT '状态 0启动，1停止',
  `version` int(11) DEFAULT '0',
  `deleted` int(11) DEFAULT '0' COMMENT '1正常，0删除',
  `pmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `pmt_update` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='参系统参数方案';

CREATE TABLE `proj1_process` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL,
  `pname` char(50) NOT NULL COMMENT '程序名称',
  `fpath` char(150) DEFAULT NULL COMMENT '程序路径',
  `status` int(2) DEFAULT NULL COMMENT '状态 0启动，1停止',
  `daemon` int(2) DEFAULT '0' COMMENT '0非守护进程，1守护进程',
  `version` int(11) DEFAULT '0',
  `deleted` int(2) DEFAULT '0' COMMENT '1正常，0删除',
  `pmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `pmt_update` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='进程表';

CREATE TABLE `proj1_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mobile` char(11) NOT NULL COMMENT '手机号',
  `password` char(255) NOT NULL COMMENT '密码',
  `level` int(2) DEFAULT '0' COMMENT '级别',
  `version` int(11) DEFAULT '0',
  `deleted` int(11) DEFAULT '0' COMMENT '1正常，0删除',
  `pmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `pmt_update` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='登录用户';