package com.ecs.monitor.config;

public class SpringMvc {
}
