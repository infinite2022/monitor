package com.ecs.monitor.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.support.http.StatViewServlet;
import com.alibaba.druid.support.http.WebStatFilter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class DruidConfig {

    @ConfigurationProperties(prefix = "spring.datasource")
    @Bean
    public DataSource druid(){
        return new DruidDataSource();
    }

    /**
     * druid监控配置—1：配置servlet用于管理后台
     * 使用ServletRegistrationBean注册servlet
     * 使用StatViewServlet控制后台管理用的servlet
     */

//    @Bean
//    public ServletRegistrationBean statViewServlet(){
//        //"/mch/*"      本servlet用于处理所有:域名/项目/mch/下的所有请求
//        ServletRegistrationBean sBean = new ServletRegistrationBean(new StatViewServlet(),"/trea/*");
//        Map<String,String> servletInitParams = new HashMap<>();
//
//        //参数在ResourceServlet中找到提示
//        servletInitParams.put("loginUsername","root");//登录用户名
//        servletInitParams.put("loginPassword","jubaokj@2019.");//登录mysql的密码
//        servletInitParams.put("allow","");//允许所有用户访问
//        //servletInitParams.put("deny","192.168.1.20");
//
//        sBean.setInitParameters(servletInitParams);
//        return sBean;
//    }

    /**
     * druid监控配置—2：配置filter
     * 将webstatfilter通过FilterRegistrationBean进行注册
     * 同时初始化webStatFilter的初始化参数
     */
//    @Bean
//    public FilterRegistrationBean webStatFilter(){
//        Map<String,String> filterInitParams = new HashMap<>();
//
//        //设置需要排除的请求：包括静态请求不拦截（js,css等）,另外也不拦截mch/的所有请求
//        filterInitParams.put("exclusions","*.js,*.css,/trea/*");
//
//        FilterRegistrationBean fBean = new  FilterRegistrationBean();
//
//        fBean.setFilter(new WebStatFilter());
//        fBean.setInitParameters(filterInitParams);
//        fBean.setUrlPatterns(Arrays.asList("/*"));
//        return fBean;
//    }

}
