package com.ecs.monitor.common
        ;

public class MyFileUtil {

    public static enum FileType{
        REST_REQUIRE_ECS_COMMAND,
        COMMAND_LOG;
    }
    public String generalFileName(FileType fileType){
        String fileName = null;
        switch(fileType){
            case REST_REQUIRE_ECS_COMMAND:
                break;
            case COMMAND_LOG:
                break;
        }
        return fileName;
    }
}
